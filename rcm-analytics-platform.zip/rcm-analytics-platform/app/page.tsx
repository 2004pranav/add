"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/dashboard/app-sidebar"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardRenderer } from "@/components/dashboard/dashboard-renderer"
import { getDashboardData } from "@/lib/mock-data"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function DashboardPage() {
  const [activeClientId, setActiveClientId] = useState("all")
  const data = getDashboardData(activeClientId)

  return (
    <SidebarProvider>
      <AppSidebar
        activeClientId={activeClientId}
        onClientChange={setActiveClientId}
      />
      <SidebarInset>
        <ScrollArea className="h-svh">
          <div className="p-6 lg:p-10">
            <DashboardHeader
              clientId={data.clientId}
              clientName={data.clientName}
              dateFrom={data.dateRange.from}
              dateTo={data.dateRange.to}
              onClientChange={setActiveClientId}
            />
            <DashboardRenderer data={data} />
          </div>
        </ScrollArea>
      </SidebarInset>
    </SidebarProvider>
  )
}
