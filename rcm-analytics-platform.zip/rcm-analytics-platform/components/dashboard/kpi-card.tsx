"use client"

import { cn } from "@/lib/utils"
import type { KpiMetric } from "@/lib/types"
import { TriangleAlert, TrendingDown, TrendingUp } from "lucide-react"

function formatValue(value: number, format: string): string {
  switch (format) {
    case "percentage":
      return `${value.toFixed(2)}%`
    case "currency":
      return `$${value.toLocaleString()}`
    case "days":
      return `${value} d`
    default:
      return value.toLocaleString()
  }
}

export function KpiCard({ metric }: { metric: KpiMetric }) {
  const isNegative = metric.changeDirection === "down"
  const isPositive = metric.changeDirection === "up"

  return (
    <div className="group relative flex flex-col justify-between rounded-xl border border-border bg-card p-5 transition-all duration-200 hover:shadow-md hover:border-primary/20">
      <div className="flex items-start justify-between gap-2">
        <span className="text-sm font-medium text-card-foreground/80 leading-tight">
          {metric.label}
        </span>
        {metric.changePercent !== undefined && (
          <div
            className={cn(
              "flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold shrink-0",
              isNegative && "bg-destructive/10 text-destructive",
              isPositive && "bg-emerald-50 text-emerald-600",
              !isNegative && !isPositive && "bg-muted text-muted-foreground"
            )}
          >
            {isNegative ? (
              <TrendingDown className="size-3" />
            ) : isPositive ? (
              <TrendingUp className="size-3" />
            ) : (
              <TriangleAlert className="size-3" />
            )}
            {metric.format === "number"
              ? metric.changePercent?.toLocaleString()
              : `${metric.changePercent?.toFixed(2)}%`}
          </div>
        )}
      </div>
      {metric.previousValue !== undefined && (
        <p className="text-xs text-muted-foreground mt-1">
          vs {metric.format === "number" ? metric.previousValue.toLocaleString() : metric.previousValue.toFixed(2)}
        </p>
      )}
      <p className="text-3xl font-bold tracking-tight text-card-foreground mt-3">
        {formatValue(metric.value, metric.format)}
      </p>
    </div>
  )
}
