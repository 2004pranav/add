"use client"

import type { KpiMetric } from "@/lib/types"
import { TrendingDown, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"

function formatValue(value: number, format: string): string {
  switch (format) {
    case "percentage":
      return `${value.toFixed(2)}%`
    case "currency":
      return `$${value.toLocaleString()}`
    case "days":
      return `${value} d`
    default:
      return value.toLocaleString()
  }
}

export function HeroBanner({ metrics }: { metrics: KpiMetric[] }) {
  if (metrics.length === 0) return null

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-primary/90 to-chart-1 p-6 lg:p-8 shadow-lg">
      {/* Decorative wave SVG */}
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.12]"
        viewBox="0 0 1200 400"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path d="M0,200 C150,100 350,300 500,180 C650,60 800,250 1000,150 C1100,100 1150,180 1200,160 L1200,400 L0,400 Z" fill="white" />
        <path d="M0,280 C200,180 400,350 600,250 C800,150 1000,300 1200,220 L1200,400 L0,400 Z" fill="white" opacity="0.5" />
        <path d="M0,320 C100,280 300,380 500,300 C700,220 900,350 1200,280 L1200,400 L0,400 Z" fill="white" opacity="0.3" />
      </svg>

      <div className="relative z-10">
        <h2 className="text-lg font-bold text-primary-foreground mb-1">Key Performance Indicators</h2>
        <p className="text-sm text-primary-foreground/70 mb-6">Overview of all revenue cycle metrics</p>
        <div className={`grid gap-4 lg:gap-6 ${
          metrics.length <= 3
            ? "grid-cols-1 sm:grid-cols-3"
            : metrics.length === 4
              ? "grid-cols-2 sm:grid-cols-4"
              : metrics.length === 5
                ? "grid-cols-2 sm:grid-cols-3 lg:grid-cols-5"
                : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-6"
        }`}>
          {metrics.map((metric) => {
            return (
              <div key={metric.key} className="min-w-0">
                <p className="text-2xl lg:text-3xl font-bold text-primary-foreground tracking-tight">
                  {formatValue(metric.value, metric.format)}
                  {metric.changePercent !== undefined && (
                    <span className="text-xs font-medium text-primary-foreground/60 ml-1.5">
                      ({metric.changePercent > 0 ? "+" : ""}{metric.format === "number" ? metric.changePercent.toLocaleString() : `${metric.changePercent.toFixed(0)}%`})
                    </span>
                  )}
                </p>
                <p className="text-xs text-primary-foreground/70 mt-1 truncate">
                  {metric.label}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
