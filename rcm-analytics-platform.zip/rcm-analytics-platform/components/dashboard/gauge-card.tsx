"use client"

import type { GaugeMetric } from "@/lib/types"
import { MoreHorizontal } from "lucide-react"

function formatGaugeValue(value: number, format: string): string {
  switch (format) {
    case "currency":
      return `$${value.toLocaleString()}`
    case "days":
      return `${value} d`
    default:
      return value.toLocaleString()
  }
}

function GaugeRing({ value, maxValue }: { value: number; maxValue: number }) {
  const percentage = Math.min((value / maxValue) * 100, 100)
  const radius = 52
  const strokeWidth = 8
  const cx = 64
  const cy = 64
  const circumference = Math.PI * radius
  const offset = circumference - (percentage / 100) * circumference

  return (
    <svg viewBox="0 0 128 80" className="w-full max-w-[128px]" aria-hidden="true">
      <path
        d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy}`}
        fill="none"
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        className="text-muted/40"
      />
      {percentage > 0 && (
        <path
          d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 ${percentage > 50 ? 1 : 0} 1 ${cx + radius * Math.cos(Math.PI - (percentage / 100) * Math.PI)} ${cy - radius * Math.sin(Math.PI - (percentage / 100) * Math.PI)}`}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          className="text-primary transition-all duration-700 ease-out"
        />
      )}
    </svg>
  )
}

export function GaugeCard({ metric }: { metric: GaugeMetric }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl bg-card p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.04)] transition-shadow duration-200 hover:shadow-[0_2px_8px_rgba(0,0,0,0.06),0_8px_24px_rgba(0,0,0,0.06)] h-full">
      <div className="self-end mb-2">
        <button className="text-muted-foreground/40 hover:text-muted-foreground transition-colors" aria-label="More options">
          <MoreHorizontal className="size-4" />
        </button>
      </div>
      <GaugeRing value={metric.value} maxValue={metric.maxValue} />
      <p className="text-xl font-bold tracking-tight text-card-foreground mt-1">
        {formatGaugeValue(metric.value, metric.format)}
      </p>
      <p className="text-xs text-muted-foreground mt-1 font-medium">{metric.label}</p>
    </div>
  )
}
