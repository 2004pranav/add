"use client"

import type { AgingBucket } from "@/lib/types"
import { MoreHorizontal } from "lucide-react"
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"

export function ArAgingBuckets({
  buckets,
  tillDate,
}: {
  buckets: AgingBucket[]
  tillDate: string
}) {
  const total = buckets.reduce((sum, b) => sum + b.amount, 0)
  const chartData = buckets.map((b) => ({
    name: b.label,
    value: b.amount || 1,
    color: b.color,
  }))

  return (
    <div className="rounded-2xl bg-card p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.04)] h-full flex flex-col">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold text-card-foreground">AR Aging Buckets</h3>
          <p className="text-xs text-muted-foreground mt-1">Till {tillDate}</p>
        </div>
        <button className="text-muted-foreground/40 hover:text-muted-foreground transition-colors" aria-label="More options">
          <MoreHorizontal className="size-4" />
        </button>
      </div>
      <div className="flex flex-col items-center flex-1">
        <div className="relative h-[170px] w-[170px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={75}
                paddingAngle={3}
                dataKey="value"
                stroke="none"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-lg font-bold text-card-foreground">
              ${total > 0 ? (total / 1000).toFixed(0) + "k" : "0"}
            </span>
            <span className="text-[10px] text-muted-foreground">Total AR</span>
          </div>
        </div>
        <div className="w-full mt-5 space-y-3">
          {buckets.map((bucket) => (
            <div key={bucket.label} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span
                  className="size-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: bucket.color }}
                  aria-hidden="true"
                />
                <span className="text-xs text-muted-foreground font-medium">{bucket.label}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-card-foreground">
                  ${bucket.amount.toLocaleString()}
                </span>
                <span className="text-[10px] text-muted-foreground w-7 text-right">
                  {total > 0 ? `${bucket.percentage}%` : "0%"}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
