"use client"

import type { AutomationMetric } from "@/lib/types"
import { MoreHorizontal } from "lucide-react"

export function AutomationPenetration({ metrics }: { metrics: AutomationMetric[] }) {
  // Adaptively choose grid columns based on metric count
  const count = metrics.length
  const innerGridClass =
    count <= 2
      ? "grid-cols-1 sm:grid-cols-2"
      : count === 3
        ? "grid-cols-1 sm:grid-cols-3"
        : count === 4
          ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
          : count === 5
            ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
            : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"

  return (
    <div className="rounded-2xl bg-card p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.04)] h-full">
      <div className="flex items-start justify-between mb-6">
        <h3 className="text-base font-semibold text-card-foreground">
          Automation Penetration
        </h3>
        <button className="text-muted-foreground/40 hover:text-muted-foreground transition-colors" aria-label="More options">
          <MoreHorizontal className="size-4" />
        </button>
      </div>
      <div className={`grid ${innerGridClass} gap-x-8 gap-y-6`}>
        {metrics.map((metric) => {
          const isPercentage = metric.key !== "fte"
          const displayValue = isPercentage
            ? `${metric.value.toFixed(1)}%`
            : metric.value.toFixed(2)
          const progressPercent = isPercentage ? metric.value : (metric.value / 10) * 100

          return (
            <div key={metric.key} className="space-y-2.5">
              <span className="text-xs text-muted-foreground font-medium">
                {metric.label}
              </span>
              <p className="text-xl font-bold text-card-foreground tracking-tight">
                {displayValue}
              </p>
              <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full rounded-full bg-primary transition-all duration-700 ease-out"
                  style={{ width: `${Math.min(progressPercent, 100)}%` }}
                />
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
