"use client"

import type { PeriodComparisonItem } from "@/lib/types"
import { MoreHorizontal } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export function PeriodComparison({
  data,
  previousLabel,
  currentLabel,
}: {
  data: PeriodComparisonItem[]
  previousLabel: string
  currentLabel: string
}) {
  const chartData = data.map((item) => ({
    name: item.metric,
    Previous: item.previous,
    Current: item.current,
  }))

  return (
    <div className="rounded-2xl bg-card p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.04)] h-full flex flex-col">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-base font-semibold text-card-foreground">Period Comparison</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {previousLabel} vs {currentLabel}
          </p>
        </div>
        <button className="text-muted-foreground/40 hover:text-muted-foreground transition-colors" aria-label="More options">
          <MoreHorizontal className="size-4" />
        </button>
      </div>
      <div className="flex-1 min-h-[240px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} layout="vertical" barGap={4} barSize={16}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="oklch(0.93 0.005 265)" />
            <XAxis
              type="number"
              domain={[0, 100]}
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11, fill: "oklch(0.55 0.02 265)" }}
            />
            <YAxis
              dataKey="name"
              type="category"
              tickLine={false}
              axisLine={false}
              width={80}
              tick={{ fontSize: 11, fill: "oklch(0.55 0.02 265)" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "white",
                border: "none",
                borderRadius: "12px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
                fontSize: "12px",
              }}
            />
            <Legend
              wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }}
              iconType="circle"
              iconSize={8}
            />
            <Bar dataKey="Previous" fill="oklch(0.85 0.02 265)" radius={[0, 6, 6, 0]} />
            <Bar dataKey="Current" fill="oklch(0.50 0.16 265)" radius={[0, 6, 6, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
