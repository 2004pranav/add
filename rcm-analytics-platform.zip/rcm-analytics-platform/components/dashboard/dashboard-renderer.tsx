"use client"

import type { DashboardData } from "@/lib/types"
import { HeroBanner } from "./hero-banner"
import { GaugeCard } from "./gauge-card"
import { PeriodComparison } from "./period-comparison"
import { AutomationPenetration } from "./automation-penetration"
import { ArAgingBuckets } from "./ar-aging-buckets"
import { PerformanceTrends } from "./performance-trends"

export function DashboardRenderer({ data }: { data: DashboardData }) {
  const hasKpis = data.kpiCards.length > 0
  const hasGauges = data.gaugeCards.length > 0
  const hasPeriod = data.periodComparison.length > 0
  const hasAutomation = data.automationMetrics.length > 0
  const hasAging = data.agingBuckets.length > 0
  const hasTrends = Object.keys(data.performanceTrends).length > 0

  // Determine gauge grid columns based on count
  const gaugeCount = data.gaugeCards.length
  const gaugeGridClass =
    gaugeCount === 1
      ? "grid-cols-1 sm:grid-cols-1 lg:grid-cols-1 max-w-xs"
      : gaugeCount === 2
        ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-2"
        : gaugeCount === 3
          ? "grid-cols-1 sm:grid-cols-3 lg:grid-cols-3"
          : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"

  // Middle row: Period Comparison + Automation
  // If both exist, split into proportional columns.
  // If only one exists, it takes the full width.
  const middleRowPresent = hasPeriod || hasAutomation
  const middleRowLayout = (() => {
    if (hasPeriod && hasAutomation) return "split"
    if (hasPeriod) return "period-only"
    if (hasAutomation) return "automation-only"
    return "none"
  })()

  // Bottom row: AR Aging + Performance Trends
  // Same adaptive logic
  const bottomRowPresent = hasAging || hasTrends
  const bottomRowLayout = (() => {
    if (hasAging && hasTrends) return "split"
    if (hasAging) return "aging-only"
    if (hasTrends) return "trends-only"
    return "none"
  })()

  return (
    <div className="flex flex-col gap-6">
      {/* Hero KPI Banner */}
      {hasKpis && (
        <section aria-label="Key Performance Indicators">
          <HeroBanner metrics={data.kpiCards} />
        </section>
      )}

      {/* Gauge Cards */}
      {hasGauges && (
        <section aria-label="Gauge Metrics">
          <div className={`grid ${gaugeGridClass} gap-5`}>
            {data.gaugeCards.map((metric) => (
              <GaugeCard key={metric.key} metric={metric} />
            ))}
          </div>
        </section>
      )}

      {/* Period Comparison & Automation */}
      {middleRowPresent && (
        <section aria-label="Analysis Panels">
          {middleRowLayout === "split" ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <div className="lg:col-span-5">
                <PeriodComparison
                  data={data.periodComparison}
                  previousLabel="JUL 25 - SEP 25"
                  currentLabel="OCT 25 - DEC 25"
                />
              </div>
              <div className="lg:col-span-7">
                <AutomationPenetration metrics={data.automationMetrics} />
              </div>
            </div>
          ) : middleRowLayout === "period-only" ? (
            <PeriodComparison
              data={data.periodComparison}
              previousLabel="JUL 25 - SEP 25"
              currentLabel="OCT 25 - DEC 25"
            />
          ) : (
            <AutomationPenetration metrics={data.automationMetrics} />
          )}
        </section>
      )}

      {/* AR Aging & Performance Trends */}
      {bottomRowPresent && (
        <section aria-label="Aging and Trends">
          {bottomRowLayout === "split" ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <div className="lg:col-span-5">
                <ArAgingBuckets buckets={data.agingBuckets} tillDate="Dec 2025" />
              </div>
              <div className="lg:col-span-7">
                <PerformanceTrends trends={data.performanceTrends} />
              </div>
            </div>
          ) : bottomRowLayout === "aging-only" ? (
            <div className="max-w-2xl">
              <ArAgingBuckets buckets={data.agingBuckets} tillDate="Dec 2025" />
            </div>
          ) : (
            <PerformanceTrends trends={data.performanceTrends} />
          )}
        </section>
      )}
    </div>
  )
}
