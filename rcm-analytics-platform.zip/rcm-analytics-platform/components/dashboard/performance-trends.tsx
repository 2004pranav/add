"use client"

import { useState } from "react"
import type { TrendDataPoint } from "@/lib/types"
import { MoreHorizontal } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { cn } from "@/lib/utils"

const tabColors: Record<string, string> = {
  GCR: "oklch(0.50 0.16 265)",
  NCR: "oklch(0.62 0.14 190)",
  "Denial Rate": "oklch(0.58 0.16 30)",
  CCR: "oklch(0.68 0.14 140)",
  FPR: "oklch(0.55 0.13 310)",
}

export function PerformanceTrends({
  trends,
}: {
  trends: Record<string, TrendDataPoint[]>
}) {
  const tabs = Object.keys(trends)
  const [activeTab, setActiveTab] = useState(tabs[0] || "GCR")
  const data = trends[activeTab] || []

  return (
    <div className="rounded-2xl bg-card p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.04)] h-full flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-6">
        <div>
          <h3 className="text-base font-semibold text-card-foreground">Performance Trends</h3>
          <p className="text-xs text-muted-foreground mt-1">Monthly trend analysis</p>
        </div>
        <div className="flex items-center gap-1 rounded-xl bg-muted/60 p-1">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-3 py-1.5 text-xs font-medium rounded-lg transition-all duration-150",
                activeTab === tab
                  ? "bg-card text-card-foreground shadow-sm"
                  : "text-muted-foreground hover:text-card-foreground"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 min-h-[240px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.93 0.005 265)" />
            <XAxis
              dataKey="month"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11, fill: "oklch(0.55 0.02 265)" }}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11, fill: "oklch(0.55 0.02 265)" }}
              domain={["auto", "auto"]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "white",
                border: "none",
                borderRadius: "12px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
                fontSize: "12px",
              }}
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke={tabColors[activeTab] || "oklch(0.50 0.16 265)"}
              strokeWidth={2.5}
              dot={{ r: 4, strokeWidth: 2, fill: "white" }}
              activeDot={{ r: 6, strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
