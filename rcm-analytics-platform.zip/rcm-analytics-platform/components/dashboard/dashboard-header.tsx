"use client"

import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Upload, Bell, Settings, Search } from "lucide-react"
import { clients } from "@/lib/mock-data"
import { SidebarTrigger } from "@/components/ui/sidebar"

export function DashboardHeader({
  clientId,
  clientName,
  dateFrom,
  dateTo,
  onClientChange,
}: {
  clientId: string
  clientName: string
  dateFrom: string
  dateTo: string
  onClientChange: (clientId: string) => void
}) {
  return (
    <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between pb-8">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="md:hidden" />
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight text-balance">
            {clientId === "all" ? "All Clients" : clientName} Dashboard
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Revenue Cycle Management Optimization
          </p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search..."
            className="w-[180px] rounded-xl border-0 bg-card pl-9 pr-3 py-2 text-sm text-foreground shadow-sm ring-1 ring-border/60 placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <Select value={clientId} onValueChange={onClientChange}>
          <SelectTrigger className="w-[160px] h-9 text-sm bg-card rounded-xl border-0 shadow-sm ring-1 ring-border/60">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {clients.map((client) => (
              <SelectItem key={client.id} value={client.id}>
                {client.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-xl size-9 bg-card shadow-sm ring-1 ring-border/60 text-muted-foreground hover:text-foreground"
        >
          <Bell className="size-4" />
          <span className="sr-only">Notifications</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-xl size-9 bg-card shadow-sm ring-1 ring-border/60 text-muted-foreground hover:text-foreground"
        >
          <Settings className="size-4" />
          <span className="sr-only">Settings</span>
        </Button>
        <Button size="sm" className="gap-2 rounded-xl shadow-sm h-9 bg-primary text-primary-foreground hover:bg-primary/90">
          <Upload className="size-3.5" />
          Upload CSVs
        </Button>
      </div>
    </header>
  )
}
