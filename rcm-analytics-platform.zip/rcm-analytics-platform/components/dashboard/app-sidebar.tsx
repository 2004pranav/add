"use client"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar"
import {
  LayoutDashboard,
  Building2,
  Settings,
  HelpCircle,
  Activity,
  User,
  LogOut,
} from "lucide-react"
import { clients } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

export function AppSidebar({
  activeClientId,
  onClientChange,
}: {
  activeClientId: string
  onClientChange: (clientId: string) => void
}) {
  const allClient = clients[0]
  const otherClients = clients.slice(1)

  return (
    <Sidebar className="border-r-0">
      <SidebarHeader className="px-5 pt-6 pb-5">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <Activity className="size-5" />
          </div>
          <div>
            <p className="text-sm font-bold text-sidebar-foreground tracking-tight">Jorie AI</p>
            <p className="text-[11px] text-muted-foreground">RCM Analytics</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="px-3">
        <SidebarGroup>
          <SidebarGroupLabel className="text-muted-foreground text-[10px] uppercase tracking-[0.12em] font-semibold px-3 mb-1">
            Home
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={activeClientId === allClient.id}
                  onClick={() => onClientChange(allClient.id)}
                  className={cn(
                    "gap-3 rounded-xl h-10 px-3 font-medium transition-all",
                    activeClientId === allClient.id
                      ? "bg-primary/10 text-primary font-semibold"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <LayoutDashboard className="size-[18px]" />
                  <span>Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-muted-foreground text-[10px] uppercase tracking-[0.12em] font-semibold px-3 mb-1">
            Clients
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {otherClients.map((client) => (
                <SidebarMenuItem key={client.id}>
                  <SidebarMenuButton
                    isActive={activeClientId === client.id}
                    onClick={() => onClientChange(client.id)}
                    className={cn(
                      "gap-3 rounded-xl h-10 px-3 font-medium transition-all",
                      activeClientId === client.id
                        ? "bg-primary/10 text-primary font-semibold"
                        : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                    )}
                  >
                    <Building2 className="size-[18px]" />
                    <span className="truncate">{client.name}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="px-5 pb-5 pt-3 border-t-0">
        <div className="flex items-center gap-3 rounded-xl bg-accent/60 px-3 py-3 mb-3">
          <div className="flex size-9 items-center justify-center rounded-full bg-primary/10">
            <User className="size-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">Admin User</p>
            <p className="text-[11px] text-muted-foreground">Administrator</p>
          </div>
        </div>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton className="gap-3 rounded-xl h-9 px-3 text-muted-foreground hover:bg-accent hover:text-accent-foreground">
              <Settings className="size-[18px]" />
              <span>Settings</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton className="gap-3 rounded-xl h-9 px-3 text-muted-foreground hover:bg-accent hover:text-accent-foreground">
              <HelpCircle className="size-[18px]" />
              <span>Help & Support</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton className="gap-3 rounded-xl h-9 px-3 text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
              <LogOut className="size-[18px]" />
              <span>Log out</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
