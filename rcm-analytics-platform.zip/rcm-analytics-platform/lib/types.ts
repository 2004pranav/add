export interface KpiMetric {
  key: string
  label: string
  value: number
  format: "percentage" | "currency" | "number" | "days"
  previousValue?: number
  changePercent?: number
  changeDirection?: "up" | "down" | "neutral"
}

export interface GaugeMetric {
  key: string
  label: string
  value: number
  format: "currency" | "days" | "number"
  maxValue: number
}

export interface AutomationMetric {
  key: string
  label: string
  value: number
}

export interface AgingBucket {
  label: string
  color: string
  amount: number
  percentage: number
}

export interface PeriodComparisonItem {
  metric: string
  previous: number
  current: number
}

export interface TrendDataPoint {
  month: string
  value: number
}

export interface ClientConfig {
  id: string
  name: string
  enabledKpis: string[]
  enabledGauges: string[]
  enabledAutomation: string[]
}

export interface DashboardData {
  clientId: string
  clientName: string
  dateRange: { from: string; to: string }
  kpiCards: KpiMetric[]
  gaugeCards: GaugeMetric[]
  periodComparison: PeriodComparisonItem[]
  automationMetrics: AutomationMetric[]
  agingBuckets: AgingBucket[]
  performanceTrends: Record<string, TrendDataPoint[]>
}
