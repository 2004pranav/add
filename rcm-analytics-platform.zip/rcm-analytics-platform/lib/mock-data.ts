import type { DashboardData, ClientConfig } from "./types"

export const clients: ClientConfig[] = [
  {
    id: "all",
    name: "All Clients",
    enabledKpis: ["gcr", "ncr", "denial_rate", "fpr", "ccr", "total_claims"],
    enabledGauges: ["total_payments", "charge_lag", "billing_lag", "ar_days"],
    enabledAutomation: ["prior_auth", "charges", "payment_posting", "account_receivable", "eligibility_verification", "fte"],
  },
  {
    id: "client-a",
    name: "Sunrise Health",
    enabledKpis: ["gcr", "ncr", "denial_rate", "fpr", "ccr", "total_claims"],
    enabledGauges: ["total_payments", "charge_lag", "billing_lag", "ar_days"],
    enabledAutomation: ["prior_auth", "charges", "payment_posting", "account_receivable", "eligibility_verification", "fte"],
  },
  {
    id: "client-b",
    name: "Meridian Medical",
    enabledKpis: ["gcr", "ncr", "denial_rate", "total_claims"],
    enabledGauges: ["total_payments", "charge_lag", "ar_days"],
    enabledAutomation: ["charges", "payment_posting", "eligibility_verification"],
  },
  {
    id: "client-c",
    name: "Pacific Ortho Group",
    enabledKpis: ["gcr", "ncr", "denial_rate", "fpr", "ccr", "total_claims"],
    enabledGauges: ["total_payments", "charge_lag", "billing_lag", "ar_days"],
    enabledAutomation: ["prior_auth", "charges", "payment_posting", "account_receivable", "eligibility_verification", "fte"],
  },
  {
    id: "client-d",
    name: "Valley Care Partners",
    enabledKpis: ["gcr", "ncr", "fpr", "total_claims"],
    enabledGauges: ["total_payments", "billing_lag", "ar_days"],
    enabledAutomation: ["prior_auth", "payment_posting", "account_receivable"],
  },
  {
    id: "client-e",
    name: "Summit Behavioral",
    enabledKpis: ["gcr", "ncr", "denial_rate", "fpr", "ccr", "total_claims"],
    enabledGauges: ["total_payments", "charge_lag", "billing_lag", "ar_days"],
    enabledAutomation: ["prior_auth", "charges", "payment_posting", "account_receivable", "eligibility_verification", "fte"],
  },
]

function generateTrendData(baseValue: number, variance: number): { month: string; value: number }[] {
  const months = ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  return months.map((month) => ({
    month,
    value: Math.max(0, baseValue + (Math.random() - 0.5) * variance),
  }))
}

export function getDashboardData(clientId: string): DashboardData {
  const client = clients.find((c) => c.id === clientId) || clients[0]
  const isAll = clientId === "all"

  return {
    clientId: client.id,
    clientName: client.name,
    dateRange: { from: "01/10/2025", to: "31/12/2025" },
    kpiCards: [
      {
        key: "gcr",
        label: "Gross Collection Rate",
        value: isAll ? 0.0 : 85.32,
        format: "percentage",
        previousValue: 25.52,
        changePercent: 25.52,
        changeDirection: "down",
      },
      {
        key: "ncr",
        label: "Net Collection Rate",
        value: isAll ? 0.0 : 92.18,
        format: "percentage",
        previousValue: 61.89,
        changePercent: 61.89,
        changeDirection: "down",
      },
      {
        key: "denial_rate",
        label: "Denial Rate",
        value: isAll ? 0.0 : 8.45,
        format: "percentage",
        previousValue: 0.25,
        changePercent: 0.25,
        changeDirection: "down",
      },
      {
        key: "fpr",
        label: "First Pass Rate",
        value: isAll ? 0.0 : 76.2,
        format: "percentage",
        previousValue: 54.18,
        changePercent: 54.18,
        changeDirection: "down",
      },
      {
        key: "ccr",
        label: "Clean Claim Rate",
        value: isAll ? 0.0 : 91.5,
        format: "percentage",
        previousValue: 42.44,
        changePercent: 42.44,
        changeDirection: "down",
      },
      {
        key: "total_claims",
        label: "Total Claims",
        value: isAll ? 0 : 6262,
        format: "number",
        previousValue: 6262,
        changePercent: 6262,
        changeDirection: "down",
      },
    ].filter((k) => client.enabledKpis.includes(k.key)),
    gaugeCards: [
      { key: "total_payments", label: "Total Payments", value: isAll ? 0 : 234500, format: "currency", maxValue: 500000 },
      { key: "charge_lag", label: "Charge Lag (Days)", value: isAll ? 0 : 3, format: "days", maxValue: 30 },
      { key: "billing_lag", label: "Billing Lag (Days)", value: isAll ? 0 : 5, format: "days", maxValue: 30 },
      { key: "ar_days", label: "AR Days", value: isAll ? 0 : 42, format: "days", maxValue: 120 },
    ].filter((g) => client.enabledGauges.includes(g.key)),
    periodComparison: [
      { metric: "GCR", previous: isAll ? 0 : 82.1, current: isAll ? 0 : 85.3 },
      { metric: "NCR", previous: isAll ? 0 : 90.5, current: isAll ? 0 : 92.2 },
      { metric: "CCR", previous: isAll ? 0 : 89.0, current: isAll ? 0 : 91.5 },
      { metric: "FPR", previous: isAll ? 0 : 73.8, current: isAll ? 0 : 76.2 },
      { metric: "Denial Rate", previous: isAll ? 0 : 9.8, current: isAll ? 0 : 8.5 },
    ],
    automationMetrics: [
      { key: "prior_auth", label: "Prior Authorization", value: isAll ? 0 : 45.2 },
      { key: "charges", label: "Charges", value: isAll ? 0 : 68.5 },
      { key: "payment_posting", label: "Payment Posting", value: isAll ? 0 : 72.3 },
      { key: "account_receivable", label: "Account Receivable", value: isAll ? 0 : 55.1 },
      { key: "eligibility_verification", label: "Eligibility Verification", value: isAll ? 0 : 81.7 },
      { key: "fte", label: "FTE", value: isAll ? 0 : 3.2 },
    ].filter((a) => client.enabledAutomation.includes(a.key)),
    agingBuckets: [
      { label: "0-30 Days", color: "#3b82f6", amount: isAll ? 0 : 125000, percentage: isAll ? 0 : 45 },
      { label: "31-60 Days", color: "#22c55e", amount: isAll ? 0 : 67000, percentage: isAll ? 0 : 24 },
      { label: "61-90 Days", color: "#f59e0b", amount: isAll ? 0 : 45000, percentage: isAll ? 0 : 16 },
      { label: "90+ Days", color: "#ef4444", amount: isAll ? 0 : 42000, percentage: isAll ? 0 : 15 },
    ],
    performanceTrends: {
      GCR: generateTrendData(isAll ? 0 : 84, 6),
      NCR: generateTrendData(isAll ? 0 : 91, 4),
      "Denial Rate": generateTrendData(isAll ? 0 : 9, 3),
      CCR: generateTrendData(isAll ? 0 : 90, 5),
      FPR: generateTrendData(isAll ? 0 : 75, 8),
    },
  }
}
