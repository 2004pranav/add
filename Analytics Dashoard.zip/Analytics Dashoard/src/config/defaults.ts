import type { LayoutConfig, KpiConfig, SectionId, KpiId } from "./types";

// All sections visible by default. A client config only needs to set
// the ones it wants to HIDE (set to false).
export const DEFAULT_LAYOUT_CONFIG: Record<SectionId, boolean> = {
  kpiCards: true,
  performanceTrends: true,
  revenueOverview: true,
  arAging: true,
  claimsVolume: true,
  periodComparison: true,
  denialReasons: true,
  clientPerformance: true,
  automationGauge: true,
  automationPenetration: true,
};

// All 8 KPIs visible by default, in their current display order.
export const DEFAULT_KPI_ORDER: KpiId[] = [
  "totalClaims",
  "totalPayments",
  "gcr",
  "ncr",
  "denialRate",
  "fpr",
  "ccr",
  "totalOpenAR",
];

// Resolves a client's LayoutConfig against the defaults.
// Returns a complete Record<SectionId, boolean> with all keys present.
export function resolveLayoutConfig(
  config: LayoutConfig
): Record<SectionId, boolean> {
  return { ...DEFAULT_LAYOUT_CONFIG, ...config.visibleSections };
}

// Resolves which KPIs to display for this client, in display order.
export function resolveVisibleKpis(config: KpiConfig): KpiId[] {
  return config.visibleKpis ?? DEFAULT_KPI_ORDER;
}
