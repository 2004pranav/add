import type { ClientConfig } from "../types";

export const southsideConfig: ClientConfig = {
  id: "southside",
  name: "Southside",
  shortName: "Southside",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
