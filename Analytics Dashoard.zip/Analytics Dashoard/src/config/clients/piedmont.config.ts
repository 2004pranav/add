import type { ClientConfig } from "../types";

export const piedmontConfig: ClientConfig = {
  id: "piedmont",
  name: "Piedmont",
  shortName: "Piedmont",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
