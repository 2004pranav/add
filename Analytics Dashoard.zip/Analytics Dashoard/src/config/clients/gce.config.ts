import type { ClientConfig } from "../types";

export const gceConfig: ClientConfig = {
  id: "gce",
  name: "GCE",
  shortName: "GCE",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
