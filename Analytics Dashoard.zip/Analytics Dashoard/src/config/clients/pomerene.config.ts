import type { ClientConfig } from "../types";

export const pomereneConfig: ClientConfig = {
  id: "pomerene",
  name: "Pomerene",
  shortName: "Pomerene",
  layout: {
    visibleSections: {
      // All sections visible by default — nothing to hide for this client
    },
  },
  kpis: {
    // All 8 KPIs shown in default order
  },
};
