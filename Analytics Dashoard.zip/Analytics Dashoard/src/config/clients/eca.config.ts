import type { ClientConfig } from "../types";

export const ecaConfig: ClientConfig = {
  id: "eca",
  name: "ECA",
  shortName: "ECA",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
