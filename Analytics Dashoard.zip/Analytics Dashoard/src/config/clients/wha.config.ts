import type { ClientConfig } from "../types";

export const whaConfig: ClientConfig = {
  id: "wha",
  name: "WHA",
  shortName: "WHA",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
