import type { ClientConfig } from "../types";

export const southtexasConfig: ClientConfig = {
  id: "southtexas",
  name: "South Texas Spine",
  shortName: "South Texas spine",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
