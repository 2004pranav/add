import type { ClientConfig } from "../types";

export const soundhealthConfig: ClientConfig = {
  id: "soundhealth",
  name: "Sound Health",
  shortName: "Sound Health",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
