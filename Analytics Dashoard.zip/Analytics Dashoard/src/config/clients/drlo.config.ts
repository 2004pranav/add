import type { ClientConfig } from "../types";

export const drloConfig: ClientConfig = {
  id: "drlo",
  name: "Dr Lo",
  shortName: "Dr Lo",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
