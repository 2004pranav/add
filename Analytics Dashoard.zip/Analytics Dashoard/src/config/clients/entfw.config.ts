import type { ClientConfig } from "../types";

export const entfwConfig: ClientConfig = {
  id: "entfw",
  name: "ENTFW",
  shortName: "ENTFW",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
