import type { ClientConfig } from "../types";

export const orthooneConfig: ClientConfig = {
  id: "orthoone",
  name: "Ortho One",
  shortName: "Ortho One",
  layout: {
    visibleSections: {},
  },
  kpis: {},
};
