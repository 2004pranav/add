import type { ClientConfig, ClientRegistryEntry } from "./types";
import { pomereneConfig } from "./clients/pomerene.config";
import { drloConfig } from "./clients/drlo.config";
import { southsideConfig } from "./clients/southside.config";
import { orthooneConfig } from "./clients/orthoone.config";
import { gceConfig } from "./clients/gce.config";
import { southtexasConfig } from "./clients/southtexas.config";
import { ecaConfig } from "./clients/eca.config";
import { piedmontConfig } from "./clients/piedmont.config";
import { soundhealthConfig } from "./clients/soundhealth.config";
import { whaConfig } from "./clients/wha.config";
import { entfwConfig } from "./clients/entfw.config";

// ─── Master Client Registry ────────────────────────────────────────────────────
// To add a new client:
//   1. Create src/config/clients/<id>.config.ts
//   2. Import it here and add it to CLIENT_REGISTRY
//   3. Drop CSV files in public/data/<id>/
// No other files need to change.
const CLIENT_REGISTRY: ClientConfig[] = [
  pomereneConfig,
  drloConfig,
  southsideConfig,
  orthooneConfig,
  gceConfig,
  southtexasConfig,
  ecaConfig,
  piedmontConfig,
  soundhealthConfig,
  whaConfig,
  entfwConfig,
];

export function getClientRegistry(): ClientRegistryEntry[] {
  return CLIENT_REGISTRY.map(({ id, name, shortName }) => ({ id, name, shortName }));
}

export function getClientConfig(id: string): ClientConfig | undefined {
  return CLIENT_REGISTRY.find((c) => c.id === id);
}

export function getAllClientConfigs(): ClientConfig[] {
  return CLIENT_REGISTRY;
}
