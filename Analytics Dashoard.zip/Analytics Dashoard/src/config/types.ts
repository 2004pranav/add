// ─── Section IDs ─────────────────────────────────────────────────────────────
// Stable identifiers for every renderable section in the layout.
// DashboardLayout uses this union to decide what to show/hide per client.
export type SectionId =
  | "kpiCards"
  | "performanceTrends"
  | "revenueOverview"
  | "arAging"
  | "claimsVolume"
  | "periodComparison"
  | "denialReasons"
  | "clientPerformance"
  | "automationGauge"
  | "automationPenetration";

// ─── KPI IDs ──────────────────────────────────────────────────────────────────
// These match the keys in ClientKpi. Used to selectively show/hide KPI cards.
export type KpiId =
  | "totalClaims"
  | "totalPayments"
  | "gcr"
  | "ncr"
  | "denialRate"
  | "fpr"
  | "ccr"
  | "totalOpenAR";

// ─── Layout Config ────────────────────────────────────────────────────────────
// Controls which sections render. Sections not listed default to true (visible).
export interface LayoutConfig {
  // Only list sections you want to HIDE (set to false).
  // Omitting a sectionId means it uses the default from DEFAULT_LAYOUT_CONFIG.
  visibleSections: Partial<Record<SectionId, boolean>>;
}

// ─── KPI Config ───────────────────────────────────────────────────────────────
// Controls which KPI cards appear in the top row, and in what order.
export interface KpiConfig {
  // If undefined, all 8 KPIs are shown in the default order.
  visibleKpis?: KpiId[];
}

// ─── CSV Column Mapping ───────────────────────────────────────────────────────
// Maps canonical field names the app understands to actual CSV column headers
// as they appear in a given client's CSV files.
// If a field uses the same name as the canonical name, it can be omitted.
export interface CsvColumnMap {
  performance?: {
    month?: string;         // default: "month"
    GCR?: string;           // default: "GCR"
    NCR?: string;           // default: "NCR"
    DR?: string;            // default: "DR"
    CCR?: string;           // default: "CCR"
    FPR?: string;           // default: "FPR"
    TotalPayments?: string; // default: "TotalPayments"
  };
  claimsVolume?: {
    month?: string;         // default: "month"
    submitted?: string;     // default: "submitted"
    processed?: string;     // default: "processed"
    denied?: string;        // default: "denied"
  };
  arAging?: {
    bucket?: string;        // default: "bucket"
    amount?: string;        // default: "amount"
  };
  denialReasons?: {
    reason?: string;        // default: "reason"
    count?: string;         // default: "count"
    percentage?: string;    // default: "percentage"
  };
  revenue?: {
    month?: string;         // default: "month"
    payments?: string;      // default: "payments"
    billed?: string;        // default: "billed"
  };
  kpis?: {
    field?: string;         // default: "field"
    value?: string;         // default: "value"
    change?: string;        // default: "change"
  };
  automation?: {
    name?: string;          // default: "name"
    value?: string;         // default: "value"
  };
}

// ─── KPI Formula Overrides ────────────────────────────────────────────────────
// A client can override how a specific KPI is derived from raw kpis.csv rows.
// Return null to fall back to the standard formula.
export type KpiFormulaFn = (rows: Record<string, string>[]) => string | null;

export interface KpiFormulas {
  totalClaims?: KpiFormulaFn;
  totalPayments?: KpiFormulaFn;
  gcr?: KpiFormulaFn;
  ncr?: KpiFormulaFn;
  denialRate?: KpiFormulaFn;
  fpr?: KpiFormulaFn;
  ccr?: KpiFormulaFn;
  totalOpenAR?: KpiFormulaFn;
}

// ─── Client Config ────────────────────────────────────────────────────────────
// The complete per-client configuration. One file per client in src/config/clients/.
export interface ClientConfig {
  // Stable URL-safe identifier. Must match the folder name in public/data/
  id: string;
  name: string;
  shortName: string;
  layout: LayoutConfig;
  kpis: KpiConfig;
  // Column name overrides for CSV parsing (optional — only needed when headers differ)
  csvColumnMap?: CsvColumnMap;
  // Per-client formula overrides (optional — only needed for unusual derivations)
  kpiFormulas?: KpiFormulas;
}

// ─── Registry Entry ───────────────────────────────────────────────────────────
// Lightweight summary used by the sidebar (no data fetching required).
export interface ClientRegistryEntry {
  id: string;
  name: string;
  shortName: string;
}
