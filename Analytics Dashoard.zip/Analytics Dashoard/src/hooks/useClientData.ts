import { useQuery } from "@tanstack/react-query";
import type {
  ClientData,
  ClientKpi,
  PerformanceDataPoint,
  ClaimsVolumePoint,
  ArAgingPoint,
  DenialReason,
  RevenuePoint,
  PeriodComparison,
  ClientPerformanceRow,
} from "@/data/clients";
import type { ClientConfig } from "@/config/types";
import { getClientConfig, getAllClientConfigs } from "@/config/registry";
import {
  fetchKpiRows,
  fetchPerformanceData,
  fetchClaimsVolume,
  fetchArAging,
  fetchDenialReasons,
  fetchRevenueData,
  fetchAutomationItems,
} from "@/services/csvService";
import { buildClientKpi } from "@/services/formulaEngine";

// ─── Derive period comparison from performance data ────────────────────────────
// Uses the last two months in the time series.
function derivePeriodComparison(
  performanceData: PerformanceDataPoint[]
): PeriodComparison[] {
  if (performanceData.length < 2) return [];
  const prev = performanceData[performanceData.length - 2];
  const curr = performanceData[performanceData.length - 1];
  return [
    { metric: "GCR", previous: prev.GCR, current: curr.GCR },
    { metric: "Total Payments", previous: prev.TotalPayments, current: curr.TotalPayments },
    { metric: "CCR", previous: prev.CCR, current: curr.CCR },
    { metric: "FPR", previous: prev.FPR, current: curr.FPR },
    { metric: "DR", previous: prev.DR, current: curr.DR },
  ];
}

// ─── Fetch data for a single client ───────────────────────────────────────────
async function fetchSingleClientData(config: ClientConfig): Promise<ClientData> {
  const map = config.csvColumnMap;

  const [
    kpiRows,
    performanceData,
    claimsVolume,
    arAging,
    denialReasons,
    revenueData,
    automationItems,
  ] = await Promise.all([
    fetchKpiRows(config.id, map?.kpis),
    fetchPerformanceData(config.id, map?.performance),
    fetchClaimsVolume(config.id, map?.claimsVolume),
    fetchArAging(config.id, map?.arAging),
    fetchDenialReasons(config.id, map?.denialReasons),
    fetchRevenueData(config.id, map?.revenue),
    fetchAutomationItems(config.id, map?.automation),
  ]);

  const kpis = buildClientKpi(kpiRows, config.kpiFormulas);
  const periodComparison = derivePeriodComparison(performanceData);

  return {
    id: config.id,
    name: config.name,
    shortName: config.shortName,
    kpis,
    performanceData,
    claimsVolume,
    arAging,
    denialReasons,
    revenueData,
    periodComparison,
    automationItems,
    clientPerformance: [],
  };
}

// ─── Aggregation helpers ───────────────────────────────────────────────────────
const avg = (arr: number[]) =>
  arr.length === 0 ? 0 : arr.reduce((a, b) => a + b, 0) / arr.length;
const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);

function deriveStatus(gcr: number): "Excellent" | "Good" | "Fair" {
  if (gcr >= 94) return "Excellent";
  if (gcr >= 91) return "Good";
  return "Fair";
}

function aggregatePerformance(allData: ClientData[]): PerformanceDataPoint[] {
  if (allData.length === 0) return [];
  const months = allData[0].performanceData.map((d) => d.month);
  return months.map((month, i) => ({
    month,
    GCR: +avg(allData.map((c) => c.performanceData[i]?.GCR ?? 0)).toFixed(1),
    NCR: +avg(allData.map((c) => c.performanceData[i]?.NCR ?? 0)).toFixed(1),
    DR: +avg(allData.map((c) => c.performanceData[i]?.DR ?? 0)).toFixed(1),
    CCR: +avg(allData.map((c) => c.performanceData[i]?.CCR ?? 0)).toFixed(1),
    FPR: +avg(allData.map((c) => c.performanceData[i]?.FPR ?? 0)).toFixed(1),
    TotalPayments: Math.round(
      sum(allData.map((c) => c.performanceData[i]?.TotalPayments ?? 0))
    ),
  }));
}

function aggregateClaimsVolume(allData: ClientData[]): ClaimsVolumePoint[] {
  if (allData.length === 0) return [];
  const months = allData[0].claimsVolume.map((d) => d.month);
  return months.map((month, i) => ({
    month,
    submitted: Math.round(sum(allData.map((c) => c.claimsVolume[i]?.submitted ?? 0))),
    processed: Math.round(sum(allData.map((c) => c.claimsVolume[i]?.processed ?? 0))),
    denied: Math.round(sum(allData.map((c) => c.claimsVolume[i]?.denied ?? 0))),
  }));
}

function aggregateArAging(allData: ClientData[]): ArAgingPoint[] {
  if (allData.length === 0) return [];
  const buckets = allData[0].arAging.map((d) => d.bucket);
  return buckets.map((bucket, i) => ({
    bucket,
    amount: Math.round(sum(allData.map((c) => c.arAging[i]?.amount ?? 0))),
  }));
}

function aggregateDenialReasons(allData: ClientData[]): DenialReason[] {
  if (allData.length === 0) return [];
  const reasons = allData[0].denialReasons.map((d) => d.reason);
  const grandTotal = sum(
    allData.flatMap((c) => c.denialReasons.map((d) => d.count))
  );
  return reasons.map((reason, i) => {
    const totalCount = sum(allData.map((c) => c.denialReasons[i]?.count ?? 0));
    return {
      reason,
      count: totalCount,
      percentage:
        grandTotal > 0 ? Math.round((totalCount / grandTotal) * 100) : 0,
    };
  });
}

function aggregateRevenue(allData: ClientData[]): RevenuePoint[] {
  if (allData.length === 0) return [];
  const months = allData[0].revenueData.map((d) => d.month);
  return months.map((month, i) => ({
    month,
    payments: Math.round(sum(allData.map((c) => c.revenueData[i]?.payments ?? 0))),
    billed: Math.round(sum(allData.map((c) => c.revenueData[i]?.billed ?? 0))),
  }));
}

function aggregateKpis(allData: ClientData[]): ClientKpi {
  if (allData.length === 0) {
    const empty = "N/A";
    const emptyChanges = { totalClaims: "0%", totalPayments: "0%", gcr: "0%", ncr: "0%", denialRate: "0%", fpr: "0%", ccr: "0%", totalOpenAR: "0%" };
    return { totalClaims: empty, totalPayments: empty, gcr: empty, ncr: empty, denialRate: empty, fpr: empty, ccr: empty, totalOpenAR: empty, changes: emptyChanges };
  }

  const parseNum = (s: string) => parseFloat(s.replace(/[$%KM,]/g, "")) || 0;

  const totalClaimsNum = sum(allData.map((c) => parseNum(c.kpis.totalClaims)));
  const totalPaymentsNum = sum(allData.map((c) => {
    const v = c.kpis.totalPayments;
    if (v.endsWith("M")) return parseFloat(v.replace(/[$M]/g, "")) * 1_000_000;
    if (v.endsWith("K")) return parseFloat(v.replace(/[$K]/g, "")) * 1_000;
    return parseNum(v);
  }));
  const avgGcr = avg(allData.map((c) => parseNum(c.kpis.gcr)));
  const avgNcr = avg(allData.map((c) => parseNum(c.kpis.ncr)));
  const avgDr = avg(allData.map((c) => parseNum(c.kpis.denialRate)));
  const avgFpr = avg(allData.map((c) => parseNum(c.kpis.fpr)));
  const avgCcr = avg(allData.map((c) => parseNum(c.kpis.ccr)));
  const totalArNum = sum(allData.map((c) => {
    const v = c.kpis.totalOpenAR;
    if (v.endsWith("M")) return parseFloat(v.replace(/[$M]/g, "")) * 1_000_000;
    if (v.endsWith("K")) return parseFloat(v.replace(/[$K]/g, "")) * 1_000;
    return parseNum(v);
  }));

  const formatDollar = (n: number) => {
    if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000) return `$${Math.round(n / 1000)}K`;
    return `$${n}`;
  };

  const avgChange = (key: keyof ClientKpi["changes"]) => {
    const vals = allData.map((c) => parseFloat(c.kpis.changes[key].replace(/[+%]/g, "")) || 0);
    const a = avg(vals);
    return a >= 0 ? `+${a.toFixed(1)}%` : `${a.toFixed(1)}%`;
  };

  return {
    totalClaims: totalClaimsNum.toLocaleString("en-US"),
    totalPayments: formatDollar(totalPaymentsNum),
    gcr: `${avgGcr.toFixed(1)}%`,
    ncr: `${avgNcr.toFixed(1)}%`,
    denialRate: `${avgDr.toFixed(1)}%`,
    fpr: `${avgFpr.toFixed(1)}%`,
    ccr: `${avgCcr.toFixed(1)}%`,
    totalOpenAR: formatDollar(totalArNum),
    changes: {
      totalClaims: avgChange("totalClaims"),
      totalPayments: avgChange("totalPayments"),
      gcr: avgChange("gcr"),
      ncr: avgChange("ncr"),
      denialRate: avgChange("denialRate"),
      fpr: avgChange("fpr"),
      ccr: avgChange("ccr"),
      totalOpenAR: avgChange("totalOpenAR"),
    },
  };
}

function buildClientPerformanceTable(allData: ClientData[]): ClientPerformanceRow[] {
  return allData.map((d) => {
    const gcrNum = parseFloat(d.kpis.gcr.replace(/%/g, "")) || 0;
    return {
      client: d.name,
      gcr: d.kpis.gcr,
      totalPayments: d.kpis.totalPayments,
      dr: d.kpis.denialRate,
      status: deriveStatus(gcrNum),
    };
  });
}

// ─── Fetch aggregated data for "All Clients" view ─────────────────────────────
async function fetchAllClientsData(): Promise<ClientData> {
  const configs = getAllClientConfigs();
  const allData = await Promise.all(configs.map(fetchSingleClientData));

  const performanceData = aggregatePerformance(allData);
  const claimsVolume = aggregateClaimsVolume(allData);
  const arAging = aggregateArAging(allData);
  const denialReasons = aggregateDenialReasons(allData);
  const revenueData = aggregateRevenue(allData);
  const kpis = aggregateKpis(allData);
  const periodComparison = derivePeriodComparison(performanceData);
  const clientPerformance = buildClientPerformanceTable(allData);

  return {
    id: "all",
    name: "All Clients",
    shortName: "All Clients",
    kpis,
    performanceData,
    claimsVolume,
    arAging,
    denialReasons,
    revenueData,
    periodComparison,
    automationItems: [],
    clientPerformance,
  };
}

// ─── Empty placeholder for the loading state ──────────────────────────────────
function emptyClientData(id: string, name: string, shortName: string): ClientData {
  return {
    id,
    name,
    shortName,
    kpis: {
      totalClaims: "—",
      totalPayments: "—",
      gcr: "—",
      ncr: "—",
      denialRate: "—",
      fpr: "—",
      ccr: "—",
      totalOpenAR: "—",
      changes: {
        totalClaims: "0%",
        totalPayments: "0%",
        gcr: "0%",
        ncr: "0%",
        denialRate: "0%",
        fpr: "0%",
        ccr: "0%",
        totalOpenAR: "0%",
      },
    },
    performanceData: [],
    claimsVolume: [],
    arAging: [],
    denialReasons: [],
    revenueData: [],
    periodComparison: [],
    automationItems: [],
    clientPerformance: [],
  };
}

// ─── Public Hook ──────────────────────────────────────────────────────────────

export interface UseClientDataResult {
  data: ClientData;
  config: ClientConfig | undefined;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
}

export function useClientData(clientId: string): UseClientDataResult {
  const isAll = clientId === "all";
  const config = isAll ? undefined : getClientConfig(clientId);

  const placeholder = isAll
    ? emptyClientData("all", "All Clients", "All Clients")
    : emptyClientData(
        clientId,
        config?.name ?? clientId,
        config?.shortName ?? clientId
      );

  const { data, isLoading, isError, error } = useQuery<ClientData, Error>({
    queryKey: ["clientData", clientId],
    queryFn: () =>
      isAll ? fetchAllClientsData() : fetchSingleClientData(config!),
    enabled: isAll || config !== undefined,
    staleTime: 5 * 60 * 1000,
    gcTime: 10 * 60 * 1000,
    retry: 1,
  });

  return {
    data: data ?? placeholder,
    config,
    isLoading,
    isError,
    error: error ?? null,
  };
}
