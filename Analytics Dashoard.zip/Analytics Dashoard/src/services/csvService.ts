import type {
  PerformanceDataPoint,
  ClaimsVolumePoint,
  ArAgingPoint,
  DenialReason,
  RevenuePoint,
  AutomationItem,
} from "@/data/clients";
import type { CsvColumnMap } from "@/config/types";

// ─── Raw CSV Parsing ──────────────────────────────────────────────────────────

// Parses a CSV string into an array of row objects keyed by header name.
function parseCSV(raw: string): Record<string, string>[] {
  const lines = raw.trim().split(/\r?\n/);
  if (lines.length < 2) return [];

  const headers = lines[0]
    .split(",")
    .map((h) => h.trim().replace(/^"|"$/g, ""));

  return lines.slice(1).map((line) => {
    // Handle quoted fields that may contain commas
    const values: string[] = [];
    let current = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === "," && !inQuotes) {
        values.push(current.trim());
        current = "";
      } else {
        current += ch;
      }
    }
    values.push(current.trim());

    const row: Record<string, string> = {};
    headers.forEach((header, i) => {
      row[header] = (values[i] ?? "").replace(/^"|"$/g, "");
    });
    return row;
  });
}

// Fetches a CSV file from public/data/{clientId}/{filename}.
// Returns [] on 404 (optional files are allowed to be missing).
async function fetchCSV(
  clientId: string,
  filename: string
): Promise<Record<string, string>[]> {
  const url = `/data/${clientId}/${filename}`;
  const response = await fetch(url);
  if (!response.ok) {
    if (response.status === 404) return [];
    throw new Error(`Failed to fetch ${url}: HTTP ${response.status}`);
  }
  const text = await response.text();
  return parseCSV(text);
}

// ─── Column Resolution ────────────────────────────────────────────────────────
// Returns the actual CSV column name given a canonical field name and an optional map.
// Falls back to the canonical name if no override is configured.
function col<T extends Record<string, string | undefined>>(
  map: T | undefined,
  field: keyof T,
  fallback: string
): string {
  return (map?.[field] as string | undefined) ?? fallback;
}

// ─── Typed Fetch Functions ────────────────────────────────────────────────────

export async function fetchKpiRows(
  clientId: string,
  columnMap?: CsvColumnMap["kpis"]
): Promise<Record<string, string>[]> {
  return fetchCSV(clientId, "kpis.csv");
}

export async function fetchPerformanceData(
  clientId: string,
  columnMap?: CsvColumnMap["performance"]
): Promise<PerformanceDataPoint[]> {
  const rows = await fetchCSV(clientId, "performance.csv");
  return rows.map((row) => ({
    month: row[col(columnMap, "month", "month")] ?? "",
    GCR: parseFloat(row[col(columnMap, "GCR", "GCR")] ?? "0") || 0,
    NCR: parseFloat(row[col(columnMap, "NCR", "NCR")] ?? "0") || 0,
    DR: parseFloat(row[col(columnMap, "DR", "DR")] ?? "0") || 0,
    CCR: parseFloat(row[col(columnMap, "CCR", "CCR")] ?? "0") || 0,
    FPR: parseFloat(row[col(columnMap, "FPR", "FPR")] ?? "0") || 0,
    TotalPayments:
      parseFloat(row[col(columnMap, "TotalPayments", "TotalPayments")] ?? "0") || 0,
  }));
}

export async function fetchClaimsVolume(
  clientId: string,
  columnMap?: CsvColumnMap["claimsVolume"]
): Promise<ClaimsVolumePoint[]> {
  const rows = await fetchCSV(clientId, "claims_volume.csv");
  return rows.map((row) => ({
    month: row[col(columnMap, "month", "month")] ?? "",
    submitted: parseInt(row[col(columnMap, "submitted", "submitted")] ?? "0", 10) || 0,
    processed: parseInt(row[col(columnMap, "processed", "processed")] ?? "0", 10) || 0,
    denied: parseInt(row[col(columnMap, "denied", "denied")] ?? "0", 10) || 0,
  }));
}

export async function fetchArAging(
  clientId: string,
  columnMap?: CsvColumnMap["arAging"]
): Promise<ArAgingPoint[]> {
  const rows = await fetchCSV(clientId, "ar_aging.csv");
  return rows.map((row) => ({
    bucket: row[col(columnMap, "bucket", "bucket")] ?? "",
    amount: parseFloat(row[col(columnMap, "amount", "amount")] ?? "0") || 0,
  }));
}

export async function fetchDenialReasons(
  clientId: string,
  columnMap?: CsvColumnMap["denialReasons"]
): Promise<DenialReason[]> {
  const rows = await fetchCSV(clientId, "denial_reasons.csv");
  return rows.map((row) => ({
    reason: row[col(columnMap, "reason", "reason")] ?? "",
    count: parseInt(row[col(columnMap, "count", "count")] ?? "0", 10) || 0,
    percentage: parseFloat(row[col(columnMap, "percentage", "percentage")] ?? "0") || 0,
  }));
}

export async function fetchRevenueData(
  clientId: string,
  columnMap?: CsvColumnMap["revenue"]
): Promise<RevenuePoint[]> {
  const rows = await fetchCSV(clientId, "revenue.csv");
  return rows.map((row) => ({
    month: row[col(columnMap, "month", "month")] ?? "",
    payments: parseFloat(row[col(columnMap, "payments", "payments")] ?? "0") || 0,
    billed: parseFloat(row[col(columnMap, "billed", "billed")] ?? "0") || 0,
  }));
}

export async function fetchAutomationItems(
  clientId: string,
  columnMap?: CsvColumnMap["automation"]
): Promise<AutomationItem[]> {
  const rows = await fetchCSV(clientId, "automation.csv");
  return rows.map((row) => ({
    name: row[col(columnMap, "name", "name")] ?? "",
    value: row[col(columnMap, "value", "value")] ?? "0.0%",
  }));
}
