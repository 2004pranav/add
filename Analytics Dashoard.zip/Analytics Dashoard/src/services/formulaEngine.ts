import type { ClientKpi } from "@/data/clients";
import type { KpiFormulas } from "@/config/types";

// ─── Standard Formatters ──────────────────────────────────────────────────────

function formatClaims(raw: string): string {
  const n = parseInt(raw.replace(/,/g, ""), 10);
  if (isNaN(n)) return raw;
  return n.toLocaleString("en-US");
}

function formatDollar(raw: string): string {
  const n = parseFloat(raw.replace(/[$,]/g, ""));
  if (isNaN(n)) return raw;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${Math.round(n / 1000)}K`;
  return `$${n}`;
}

function formatPercent(raw: string): string {
  const n = parseFloat(raw.replace(/%/g, ""));
  if (isNaN(n)) return raw;
  return `${n.toFixed(1)}%`;
}

function formatChange(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed || trimmed === "N/A") return "0%";
  if (trimmed.startsWith("+") || trimmed.startsWith("-")) return trimmed;
  const n = parseFloat(trimmed.replace(/%/g, ""));
  if (isNaN(n)) return trimmed;
  return n >= 0 ? `+${n.toFixed(1)}%` : `${n.toFixed(1)}%`;
}

// ─── Standard KPI Row Extractor ───────────────────────────────────────────────
// Reads from flat kpis.csv rows (columns: field, value, change).
// The "field" column values must match KpiId names (case-insensitive).
function extractField(
  rows: Record<string, string>[],
  field: string
): { value: string; change: string } {
  const row = rows.find(
    (r) =>
      r["field"] === field ||
      r["field"]?.toLowerCase() === field.toLowerCase()
  );
  return {
    value: row?.["value"] ?? "N/A",
    change: row?.["change"] ?? "0%",
  };
}

// ─── Standard Formula Library ─────────────────────────────────────────────────
// Default implementations for each KPI field. Reads directly from kpis.csv rows.

const STANDARD_FORMULAS: Required<KpiFormulas> = {
  totalClaims: (rows) => formatClaims(extractField(rows, "totalClaims").value),
  totalPayments: (rows) => formatDollar(extractField(rows, "totalPayments").value),
  gcr: (rows) => formatPercent(extractField(rows, "gcr").value),
  ncr: (rows) => formatPercent(extractField(rows, "ncr").value),
  denialRate: (rows) => formatPercent(extractField(rows, "denialRate").value),
  fpr: (rows) => formatPercent(extractField(rows, "fpr").value),
  ccr: (rows) => formatPercent(extractField(rows, "ccr").value),
  totalOpenAR: (rows) => formatDollar(extractField(rows, "totalOpenAR").value),
};

// ─── Main Engine ──────────────────────────────────────────────────────────────

export function buildClientKpi(
  rows: Record<string, string>[],
  overrides?: KpiFormulas
): ClientKpi {
  const resolve = (
    field: keyof KpiFormulas,
    rows: Record<string, string>[]
  ): string => {
    const overrideFn = overrides?.[field];
    if (overrideFn) {
      const result = overrideFn(rows);
      if (result !== null) return result;
    }
    return STANDARD_FORMULAS[field](rows) ?? "N/A";
  };

  const changeFor = (field: string): string =>
    formatChange(extractField(rows, field).change);

  return {
    totalClaims: resolve("totalClaims", rows),
    totalPayments: resolve("totalPayments", rows),
    gcr: resolve("gcr", rows),
    ncr: resolve("ncr", rows),
    denialRate: resolve("denialRate", rows),
    fpr: resolve("fpr", rows),
    ccr: resolve("ccr", rows),
    totalOpenAR: resolve("totalOpenAR", rows),
    changes: {
      totalClaims: changeFor("totalClaims"),
      totalPayments: changeFor("totalPayments"),
      gcr: changeFor("gcr"),
      ncr: changeFor("ncr"),
      denialRate: changeFor("denialRate"),
      fpr: changeFor("fpr"),
      ccr: changeFor("ccr"),
      totalOpenAR: changeFor("totalOpenAR"),
    },
  };
}
