import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";
import { useState } from "react";
import type {
  PerformanceDataPoint, ClaimsVolumePoint, ArAgingPoint, DenialReason,
  RevenuePoint, PeriodComparison, AutomationItem, ClientPerformanceRow,
} from "@/data/clients";

const BLUE = "hsl(221, 83%, 53%)";
const GREEN = "hsl(160, 84%, 39%)";
const PURPLE = "hsl(262, 83%, 58%)";
const AMBER = "hsl(38, 92%, 50%)";
const RED = "hsl(0, 72%, 51%)";
const COLORS = [BLUE, GREEN, PURPLE, AMBER, RED];

const tooltipStyle = {
  borderRadius: "12px",
  border: "1px solid hsl(220, 13%, 91%)",
  boxShadow: "0 8px 24px -4px rgba(0,0,0,0.12), 0 2px 6px -2px rgba(0,0,0,0.06)",
  fontSize: "12px",
  padding: "8px 12px",
  backgroundColor: "hsl(0, 0%, 100%)",
};

const tickStyle = { fontSize: 11, fill: "hsl(220, 9%, 46%)" };
const gridStroke = "hsl(220, 13%, 93%)";

// ===== Performance Trends + Revenue =====
interface PerformanceTrendsAndRevenueProps {
  performanceData: PerformanceDataPoint[];
  revenueData: RevenuePoint[];
}

const baselineData: Record<string, number> = {
  GCR: 86.5, "Total Payments": 80.2, DR: 9.4, CCR: 88.7, FPR: 83.1,
};

export function PerformanceTrendsAndRevenueChart({ performanceData, revenueData }: PerformanceTrendsAndRevenueProps) {
  const [metric, setMetric] = useState("GCR");

  return (
    <Card className="card-elevated border-0 overflow-hidden">
      <CardContent className="p-0">
        <div className="grid grid-cols-1 divide-y divide-border/50 lg:grid-cols-2 lg:divide-x lg:divide-y-0">
          {/* Performance Trends */}
          <div className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-bold text-card-foreground tracking-tight">Performance Trends</h3>
              <Tabs value={metric} onValueChange={setMetric}>
                <TabsList className="h-8 gap-0 rounded-xl bg-secondary/80 p-0.5">
                  {["GCR", "Total Payments", "DR", "CCR", "FPR"].map((m) => (
                    <TabsTrigger key={m} value={m} className="h-7 rounded-lg px-2.5 text-[10px] font-semibold data-[state=active]:shadow-sm">{m}</TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </div>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke={gridStroke} strokeDasharray="3 3" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={tickStyle} />
                  <YAxis
                    axisLine={false} tickLine={false} tick={tickStyle}
                    tickFormatter={(v) => metric === "Total Payments" ? `$${(v / 1000000).toFixed(1)}M` : `${v}%`}
                    domain={["auto", "auto"]}
                  />
                  <Tooltip
                    contentStyle={tooltipStyle}
                    formatter={(value: number) => [
                      metric === "Total Payments" ? `$${(value / 1000000).toFixed(2)}M` : `${value.toFixed(1)}%`,
                      metric,
                    ]}
                  />
                  {metric !== "Total Payments" && baselineData[metric] && (
                    <ReferenceLine y={baselineData[metric]} stroke={PURPLE} strokeDasharray="6 4" strokeWidth={1.5} />
                  )}
                  <Line
                    type="monotone"
                    dataKey={metric === "Total Payments" ? "TotalPayments" : metric}
                    stroke={BLUE}
                    strokeWidth={2.5}
                    dot={{ r: 3.5, fill: "#fff", stroke: BLUE, strokeWidth: 2 }}
                    activeDot={{ r: 5, strokeWidth: 0, fill: BLUE }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-6 pt-2">
              <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
                <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: BLUE }} />Current Average
              </div>
              <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
                <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: PURPLE }} />Pre-Jorie Baseline
              </div>
            </div>
          </div>

          {/* Revenue Overview */}
          <div className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-bold text-card-foreground tracking-tight">Revenue Overview</h3>
              <span className="rounded-lg bg-secondary/80 px-2.5 py-1 text-[10px] font-semibold text-muted-foreground">Last 8 months</span>
            </div>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke={gridStroke} strokeDasharray="3 3" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={tickStyle} />
                  <YAxis axisLine={false} tickLine={false} tick={tickStyle} tickFormatter={(v) => `$${(v / 1000000).toFixed(1)}M`} />
                  <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => [`$${(value / 1000000).toFixed(2)}M`]} />
                  <defs>
                    <linearGradient id="gradBilled" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={PURPLE} stopOpacity={0.15} />
                      <stop offset="100%" stopColor={PURPLE} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradPayments" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={BLUE} stopOpacity={0.2} />
                      <stop offset="100%" stopColor={BLUE} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="billed" stroke={PURPLE} fill="url(#gradBilled)" strokeWidth={2} dot={false} name="Billed" />
                  <Area type="monotone" dataKey="payments" stroke={BLUE} fill="url(#gradPayments)" strokeWidth={2} dot={false} name="Payments" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-6 pt-2">
              <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
                <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: BLUE }} />Payments
              </div>
              <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
                <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: PURPLE }} />Billed
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Automation Analytics Gauge (Speedometer) =====
interface AutomationAnalyticsGaugeProps {
  items: AutomationItem[];
}

export function AutomationAnalyticsGauge({ items }: AutomationAnalyticsGaugeProps) {
  const numericValues = items
    .map((item) => parseFloat(item.value))
    .filter((v) => !isNaN(v));
  const avgScore = numericValues.length > 0
    ? numericValues.reduce((a, b) => a + b, 0) / numericValues.length
    : 0;
  const score = Math.min(Math.round(avgScore), 100);

  // Gauge geometry
  const size = 200;
  const cx = size / 2;
  const cy = size / 2 + 10;
  const r = 72;
  const thick = 10;
  const startDeg = 225;
  const endDeg = -45;
  const sweep = startDeg - endDeg; // 270°

  const toRad = (d: number) => (d * Math.PI) / 180;
  const point = (deg: number, radius: number) => ({
    x: cx + radius * Math.cos(toRad(deg)),
    y: cy - radius * Math.sin(toRad(deg)),
  });

  // Create arc path using stroke-dasharray technique
  const circumference = 2 * Math.PI * r;
  const arcLen = (sweep / 360) * circumference;
  const scoreLen = (score / 100) * arcLen;

  // Rotation: SVG circle starts at 3 o'clock (0°), we want to start at 225° (bottom-left)
  // 225° in standard = 135° clockwise from top in SVG terms
  const rotationOffset = 90 + (360 - startDeg); // = 90 + 135 = 225° but in SVG CW

  // Needle
  const needleDeg = startDeg - (score / 100) * sweep;
  const needleTip = point(needleDeg, r - thick / 2 + 2);

  // Color zones for the background
  const zoneColors = [
    { pct: 0.33, color: "hsl(0, 72%, 92%)" },
    { pct: 0.33, color: "hsl(43, 96%, 90%)" },
    { pct: 0.34, color: "hsl(152, 60%, 88%)" },
  ];

  const getScoreColor = (v: number) => {
    if (v >= 70) return GREEN;
    if (v >= 40) return AMBER;
    return RED;
  };

  const getLabel = (v: number) => {
    if (v >= 70) return "Excellent";
    if (v >= 40) return "Good";
    return "Needs Improvement";
  };

  // Minor ticks every 10, major every 25
  const tickMarks = Array.from({ length: 11 }, (_, i) => i * 10);

  return (
    <Card className="card-elevated border-0">
      <CardHeader className="pb-0">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">Automation Analytics</CardTitle>
      </CardHeader>
      <CardContent className="pt-2 flex flex-col items-center">
        <div className="relative" style={{ width: size, height: size * 0.72 }}>
          <svg
            width={size}
            height={size * 0.72}
            viewBox={`0 0 ${size} ${size * 0.72}`}
            overflow="visible"
          >
            <defs>
              <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={RED} />
                <stop offset="45%" stopColor={AMBER} />
                <stop offset="100%" stopColor={GREEN} />
              </linearGradient>
              <filter id="needleShadow">
                <feDropShadow dx="0" dy="1" stdDeviation="2" floodOpacity="0.25" />
              </filter>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Background zone arcs */}
            {zoneColors.map((zone, i) => {
              const zoneStart = startDeg - (i === 0 ? 0 : zoneColors.slice(0, i).reduce((a, z) => a + z.pct, 0)) * sweep;
              const zoneEnd = startDeg - zoneColors.slice(0, i + 1).reduce((a, z) => a + z.pct, 0) * sweep;
              const s = point(zoneStart, r);
              const e = point(zoneEnd, r);
              const large = zoneStart - zoneEnd > 180 ? 1 : 0;
              return (
                <path
                  key={i}
                  d={`M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 0 ${e.x} ${e.y}`}
                  fill="none"
                  stroke={zone.color}
                  strokeWidth={thick}
                  strokeLinecap={i === 0 || i === zoneColors.length - 1 ? "round" : "butt"}
                />
              );
            })}

            {/* Score arc overlay */}
            {score > 0 && (() => {
              const s = point(startDeg, r);
              const e = point(needleDeg, r);
              const large = startDeg - needleDeg > 180 ? 1 : 0;
              return (
                <path
                  d={`M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 0 ${e.x} ${e.y}`}
                  fill="none"
                  stroke="url(#gaugeGrad)"
                  strokeWidth={thick + 2}
                  strokeLinecap="round"
                  filter="url(#glow)"
                />
              );
            })()}

            {/* Tick marks */}
            {tickMarks.map((t) => {
              const deg = startDeg - (t / 100) * sweep;
              const isMajor = t % 25 === 0;
              const outerR = r + thick / 2 + 2;
              const innerR = r + thick / 2 + (isMajor ? 8 : 5);
              const o = point(deg, outerR);
              const n = point(deg, innerR);
              const labelPt = point(deg, r + thick / 2 + (isMajor ? 20 : 0));
              return (
                <g key={t}>
                  <line
                    x1={o.x} y1={o.y} x2={n.x} y2={n.y}
                    stroke={isMajor ? "hsl(220, 9%, 55%)" : "hsl(220, 9%, 78%)"}
                    strokeWidth={isMajor ? 1.5 : 1}
                    strokeLinecap="round"
                  />
                  {isMajor && (
                    <text
                      x={labelPt.x} y={labelPt.y}
                      textAnchor="middle" dominantBaseline="middle"
                      fill="hsl(220, 9%, 50%)" fontSize="8" fontWeight="600"
                      fontFamily="system-ui, sans-serif"
                    >
                      {t}%
                    </text>
                  )}
                </g>
              );
            })}

            {/* Needle */}
            <g filter="url(#needleShadow)">
              <line
                x1={cx} y1={cy}
                x2={needleTip.x} y2={needleTip.y}
                stroke="hsl(220, 20%, 25%)"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </g>

            {/* Center hub */}
            <circle cx={cx} cy={cy} r="7" fill="hsl(220, 20%, 25%)" />
            <circle cx={cx} cy={cy} r="3.5" fill="hsl(0, 0%, 98%)" />
          </svg>
        </div>

        {/* Score display */}
        <div className="text-center -mt-1">
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-3xl font-extrabold tracking-tight text-card-foreground">{score}</span>
            <span className="text-lg font-bold text-muted-foreground">%</span>
          </div>
          <span
            className="mt-1 inline-block rounded-full px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider"
            style={{
              color: getScoreColor(score),
              backgroundColor: `${getScoreColor(score)}18`,
            }}
          >
            {getLabel(score)}
          </span>
          <p className="text-[11px] text-muted-foreground font-medium mt-1.5">Overall Automation Score</p>
        </div>
      </CardContent>
    </Card>
  );
}
interface AutomationPenetrationProps {
  items: AutomationItem[];
}

export function AutomationPenetrationCard({ items }: AutomationPenetrationProps) {
  return (
    <Card className="card-elevated border-0">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">Automation Penetration</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="grid grid-cols-3 gap-x-3 gap-y-3">
          {items.map((item) => (
            <div key={item.name} className="group flex flex-col gap-1.5 rounded-xl bg-secondary/40 p-3 transition-colors hover:bg-secondary/70">
              <span className="text-[11px] font-medium text-muted-foreground">{item.name}</span>
              <span className="text-lg font-bold text-card-foreground tracking-tight">{item.value}</span>
              <div className="h-1 w-full rounded-full bg-primary/10 overflow-hidden">
                <div className="h-full rounded-full bg-gradient-to-r from-primary to-accent" style={{ width: `${Math.min(parseFloat(item.value) || 50, 100)}%` }} />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ===== AR Aging Buckets (Donut) =====
interface ArAgingProps {
  data: ArAgingPoint[];
}

export function ArAgingChart({ data }: ArAgingProps) {
  return (
    <Card className="card-elevated border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">AR Aging Buckets</CardTitle>
        <span className="rounded-lg bg-secondary/80 px-2.5 py-1 text-[10px] font-semibold text-muted-foreground">Till Feb 2026</span>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center gap-6">
          <div className="h-48 w-48 shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data} dataKey="amount" nameKey="bucket" cx="50%" cy="50%" innerRadius={50} outerRadius={75} strokeWidth={3} stroke="hsl(0,0%,100%)">
                  {data.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => [`$${(value / 1000).toFixed(0)}K`]} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-col gap-3">
            {data.map((d, i) => (
              <div key={d.bucket} className="flex items-center gap-3">
                <span className="inline-block h-3 w-3 rounded-md" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-card-foreground">{d.bucket}</span>
                  <span className="text-[11px] text-muted-foreground font-medium">${(d.amount / 1000).toFixed(0)}K</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Claims Volume =====
interface ClaimsVolumeProps {
  data: ClaimsVolumePoint[];
}

export function ClaimsVolumeChart({ data }: ClaimsVolumeProps) {
  return (
    <Card className="card-elevated border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">Claims Volume</CardTitle>
        <span className="rounded-lg bg-secondary/80 px-2.5 py-1 text-[10px] font-semibold text-muted-foreground">Monthly</span>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke={gridStroke} strokeDasharray="3 3" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={tickStyle} />
              <YAxis axisLine={false} tickLine={false} tick={tickStyle} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="submitted" fill={BLUE} radius={[4, 4, 0, 0]} barSize={12} name="Submitted" />
              <Bar dataKey="processed" fill={GREEN} radius={[4, 4, 0, 0]} barSize={12} name="Processed" />
              <Bar dataKey="denied" fill={RED} radius={[4, 4, 0, 0]} barSize={12} name="Denied" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-6 pt-3">
          {[{ label: "Submitted", color: BLUE }, { label: "Processed", color: GREEN }, { label: "Denied", color: RED }].map((l) => (
            <div key={l.label} className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: l.color }} />{l.label}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Period Comparison =====
interface PeriodComparisonProps {
  data: PeriodComparison[];
}

export function PeriodComparisonChart({ data }: PeriodComparisonProps) {
  return (
    <Card className="card-elevated border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">Period Comparison</CardTitle>
        <div className="flex items-center gap-3">
          <span className="rounded-lg bg-secondary/80 px-2 py-0.5 text-[9px] font-bold text-muted-foreground tracking-wide">PREV</span>
          <span className="rounded-lg bg-primary/10 px-2 py-0.5 text-[9px] font-bold text-primary tracking-wide">FEB 2026</span>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-col gap-3.5">
          {data.map((d) => {
            const max = Math.max(d.previous, d.current, 100);
            return (
              <div key={d.metric} className="flex items-center gap-3">
                <span className="w-20 text-right text-[11px] font-semibold text-muted-foreground">{d.metric}</span>
                <div className="flex flex-1 flex-col gap-1.5">
                  <div className="h-2.5 rounded-full bg-secondary/60 overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-primary to-primary/80 transition-all duration-500" style={{ width: `${(d.current / max) * 100}%` }} />
                  </div>
                  <div className="h-2.5 rounded-full bg-secondary/60 overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-accent/60 to-accent/40 transition-all duration-500" style={{ width: `${(d.previous / max) * 100}%` }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-center gap-6 pt-4">
          <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
            <span className="inline-block h-2.5 w-2.5 rounded-md" style={{ backgroundColor: PURPLE }} />Previous
          </div>
          <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
            <span className="inline-block h-2.5 w-2.5 rounded-md" style={{ backgroundColor: BLUE }} />Current
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Top Denial Reasons =====
interface DenialReasonsProps {
  data: DenialReason[];
}

export function DenialReasonsChart({ data }: DenialReasonsProps) {
  const maxCount = Math.max(...data.map((d) => d.count));
  return (
    <Card className="card-elevated border-0">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">Top Denial Reasons</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-col gap-3.5">
          {data.map((d, i) => (
            <div key={d.reason} className="flex items-center gap-3">
              <span className="w-28 text-[11px] font-semibold text-card-foreground truncate">{d.reason}</span>
              <div className="flex flex-1 items-center gap-2.5">
                <div className="h-3.5 flex-1 rounded-full bg-secondary/50 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${(d.count / maxCount) * 100}%`, background: `linear-gradient(90deg, ${COLORS[i % COLORS.length]}, ${COLORS[i % COLORS.length]}cc)` }}
                  />
                </div>
                <span className="w-8 text-right text-xs font-bold text-card-foreground">{d.count}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ===== Client Performance Table =====
interface ClientPerformanceTableProps {
  data: ClientPerformanceRow[];
}

const statusColors: Record<string, string> = {
  Excellent: "text-chart-green bg-chart-green/10 ring-1 ring-chart-green/20",
  Good: "text-chart-blue bg-chart-blue/10 ring-1 ring-chart-blue/20",
  Fair: "text-chart-amber bg-chart-amber/10 ring-1 ring-chart-amber/20",
};

export function ClientPerformanceTable({ data }: ClientPerformanceTableProps) {
  return (
    <Card className="card-elevated border-0">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-bold text-card-foreground tracking-tight">Client Performance</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-border/60">
              <th className="pb-3 text-left text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Client</th>
              <th className="pb-3 text-right text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">GCR</th>
              <th className="pb-3 text-right text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Payments</th>
              <th className="pb-3 text-right text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">DR</th>
              <th className="pb-3 text-right text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody>
            {data.map((row) => (
              <tr key={row.client} className="border-b border-border/30 last:border-0 transition-colors hover:bg-secondary/30">
                <td className="py-3 font-semibold text-card-foreground">{row.client}</td>
                <td className="py-3 text-right text-card-foreground font-medium">{row.gcr}</td>
                <td className="py-3 text-right text-card-foreground font-medium">{row.totalPayments}</td>
                <td className="py-3 text-right text-card-foreground font-medium">{row.dr}</td>
                <td className="py-3 text-right">
                  <span className={`inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold ${statusColors[row.status] || ""}`}>
                    {row.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
