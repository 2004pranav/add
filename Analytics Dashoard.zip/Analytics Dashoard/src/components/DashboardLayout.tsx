import { DashboardSidebar } from "@/components/DashboardSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { KpiCards } from "@/components/KpiCards";
import {
  PerformanceTrendsAndRevenueChart,
  AutomationPenetrationCard,
  AutomationAnalyticsGauge,
  ArAgingChart,
  ClaimsVolumeChart,
  PeriodComparisonChart,
  DenialReasonsChart,
  ClientPerformanceTable,
} from "@/components/DashboardCharts";
import type { ClientData } from "@/data/clients";

interface DashboardLayoutProps {
  client: ClientData;
}

export function DashboardLayout({ client }: DashboardLayoutProps) {
  return (
    <div className="flex h-screen overflow-hidden">
      <DashboardSidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <DashboardHeader title="Dashboard" />
        <main className="flex-1 overflow-y-auto bg-background p-6">
          <div className="mx-auto flex max-w-[1600px] gap-5">
            {/* Left 70% - Main content */}
            <div className="flex flex-[7] flex-col gap-5 min-w-0">
              {/* KPI Cards */}
              <KpiCards kpis={client.kpis} />

              {/* Performance Trends + Revenue Overview */}
              <PerformanceTrendsAndRevenueChart
                performanceData={client.performanceData}
                revenueData={client.revenueData}
              />

              {/* AR Aging + Claims Volume + Period Comparison */}
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                <ArAgingChart data={client.arAging} />
                <ClaimsVolumeChart data={client.claimsVolume} />
                <PeriodComparisonChart data={client.periodComparison} />
              </div>

              {/* Denial Reasons + Client Performance */}
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <DenialReasonsChart data={client.denialReasons} />
                <ClientPerformanceTable data={client.clientPerformance} />
              </div>
            </div>

            {/* Right 30% - Automation Analytics sidebar */}
            <div className="hidden flex-[3] flex-col gap-0 lg:flex">
              <div className="flex flex-col gap-5 sticky top-0">
                <AutomationAnalyticsGauge items={client.automationItems} />
                <AutomationPenetrationCard items={client.automationItems} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
